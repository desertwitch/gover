#!/bin/bash
rm -f gover
CGO_ENABLED=0 GOFLAGS="-mod=vendor" go build -ldflags="-w -s -buildid=" -trimpath -o gover ./cmd/gover
echo $?
ldd gover
file gover
