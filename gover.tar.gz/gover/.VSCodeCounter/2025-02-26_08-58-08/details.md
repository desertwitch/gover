# Details

Date : 2025-02-26 08:58:08

Directory /home/desertwitch/gover

Total : 12 files,  1603 codes, 0 comments, 317 blanks, all 1920 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [allocation.go](/allocation.go) | Go | 276 | 0 | 54 | 330 |
| [errors.go](/errors.go) | Go | 15 | 0 | 4 | 19 |
| [filesystem.go](/filesystem.go) | Go | 226 | 0 | 50 | 276 |
| [go.mod](/go.mod) | Go Module File | 9 | 0 | 6 | 15 |
| [go.sum](/go.sum) | Go Checksum File | 14 | 0 | 1 | 15 |
| [helpers.go](/helpers.go) | Go | 71 | 0 | 13 | 84 |
| [io.go](/io.go) | Go | 281 | 0 | 62 | 343 |
| [main.go](/main.go) | Go | 128 | 0 | 9 | 137 |
| [pathing.go](/pathing.go) | Go | 99 | 0 | 16 | 115 |
| [structs.go](/structs.go) | Go | 160 | 0 | 35 | 195 |
| [unraid.go](/unraid.go) | Go | 162 | 0 | 40 | 202 |
| [validation.go](/validation.go) | Go | 162 | 0 | 27 | 189 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)