# Summary

Date : 2025-02-26 08:58:08

Directory /home/desertwitch/gover

Total : 12 files,  1603 codes, 0 comments, 317 blanks, all 1920 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Go | 10 | 1,580 | 0 | 310 | 1,890 |
| Go Checksum File | 1 | 14 | 0 | 1 | 15 |
| Go Module File | 1 | 9 | 0 | 6 | 15 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 12 | 1,603 | 0 | 317 | 1,920 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)